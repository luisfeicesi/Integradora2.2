package ui;

import java.util.Scanner;

import model.Controller;

public class Main {
    public Controller controller;
    public Scanner scan;

    public Main() {
        controller = new Controller();
        scan = new Scanner(System.in);
    }

    public static void main(String[] args) {
        Main main = new Main();
        main.menu();
    }

    public void menu() {
        while (true) {
            System.out.println("\n \n  ..Bienvenido a los confines mas vastos del universo.. ");
            System.out.println("--Ingrese una opcion--");
            System.out.println("1. Crear Galaxias");
            System.out.println("2. Crear un agujero negro");
            System.out.println("3. Crear un planeta");
            System.out.println("4. Eliminar un planeta.");
            System.out.println("5. Modificar los datos de un planeta.");            
            System.out.println("6. Agregar una foto.");
            System.out.println("7. Consultar la información de una galaxia, para lo cual deberá desplegar sus atributos y fotos.");
            System.out.println("8. Consultar la info de un planeta");            
            System.out.println("9. Consultar la galaxia mas alejada.");
            System.out.println("10. Consultar el nombre del planeta con mayor densidad.");
            System.out.println("11. Consultar los nombres de agujeros negros por tipo de agujero negro junto al nombre de la galaxia.");
            System.out.println("12. Nombre le telescopio con mayor numero de fotos registrada.");
            System.out.println("13. Creacion de casos de prueba.");
            

            int option = scan.nextInt();
            scan.nextLine();
            switch (option) {
                case 1:
                    createGalaxy();
                    break;
                case 2:
                    addBlackhole();
                    break;
                case 3:
                    createPlanet();
                    break;
                case 4:
                    deletePlanet();
                    break;
                case 5:
                    customPlanet();
                    break;
                case 6:
                    addPhoto();
                    break;
                case 7:
                    showGalaxyInfo();
                    break;
                case 8:
                    showPlanetInfo();
                    break;
                case 9:
                    System.out.println(controller.consultFarthestGalaxy());
                    break;
                case 10:
                    System.out.println(controller.consultPlanetWithMoreDensity());
                    break;
                case 11:
                    System.out.println(controller.consultBlackHoleByType());
                    break;
                case 12:
                    System.out.println(controller.consultTelescopeWithMorePhotos());
                    break;
                case 13:
                    controller.testCase();
                    break;

            }
        }
    }


    public void createGalaxy() {
        System.out.println("Hola, ingresa el nombre de la Galaxia");
        String name = scan.nextLine();
        System.out.println("Ahora, ingresa la distancia de la galaxia con respecto a la tierra");
        double distance = scan.nextDouble();
        scan.nextLine();
        System.out.println("Ingresa el id de la forma");
        System.out.println(controller.showShapesGalaxy());
        int shape = scan.nextInt();
        scan.nextLine();

        if (controller.createGalaxy(name, distance, shape )) {
            System.out.println("Se creo correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }

    public void addBlackhole() {
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Ingrese el nombre de la galaxia");
        String nameGalaxy = scan.nextLine();
        System.out.println("Ingresa el nombre del agujero negro");
        String name = scan.nextLine();
        System.out.println("jaja, ahora ingresa la distancia del agujero negro con respecto a la tierra");
        double distanceBlack = scan.nextDouble();
        scan.nextLine();
        System.out.println("Ingrese la masa del agujero negro");
        double masa = scan.nextDouble();
        scan.nextLine();
        System.out.println("Ingresa el id del tipo según su carga y momento angular");
        System.out.println(controller.showShapesBlackhole());
        int type = scan.nextInt();
        scan.nextLine();
        if (controller.createBlackhole(nameGalaxy, name, masa, distanceBlack, type-1)){
            System.out.println("Se creo correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }



    public void createPlanet() {
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();

        System.out.println("Ingresa el nombre del planeta");
        String name = scan.nextLine();
        System.out.println("Ingresa el numero de los satelites");
        int numberSatellite = scan.nextInt();
        System.out.println("Ingresa el radio");
        double radio = scan.nextDouble();
        System.out.println("Ingresa la masa");
        double masa = scan.nextDouble();
        if (controller.createPlanet(galaxia, name, numberSatellite, radio, masa)) {
            System.out.println("Se creo correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }

    }

    public void deletePlanet() {
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println("Ingresa el nombre del planeta");
        String name = scan.nextLine();
        if (controller.deletePlanet(galaxia, name)) {
            System.out.println("Se elimino correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }

    public void customPlanet(){
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println("Ingresa el nombre del planeta");
        String oldNamePlanet = scan.nextLine();
        System.out.println("Ingresa el nuevo nombre del planeta");
        String newNamePlanet = scan.nextLine();
        System.out.println("Ingresa el numero de los satelites");
        int numberSatellite = scan.nextInt();
        System.out.println("Ingresa el radio");
        double radio = scan.nextDouble();
        System.out.println("Ingresa la masa");
        double masa = scan.nextDouble();
        if (controller.customPlanet(galaxia, oldNamePlanet, newNamePlanet, numberSatellite, radio, masa)) {
            System.out.println("Se modifico correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }

    public void addPhoto(){
        System.out.println("Que tipo de foto desea agregar?");
        System.out.println("1. Galaxia");
        System.out.println("2. BlackHole");
        System.out.println("3. Planet");
        int option = scan.nextInt();
        scan.nextLine();
        switch (option) {
            case 1:
                addPhotoGalaxy();
                break;
            case 2:
                addPhotoBlackHole();
                break;
            case 3:
                addPhotoPlanet();
                break;
        }
    }

    public void addPhotoGalaxy(){
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println("Ingresa la url de la foto");
        String url = scan.nextLine();
        System.out.println("Ingresa el telescopio");
        System.out.println(controller.showTelescopes());
        int telescope = scan.nextInt();
        scan.nextLine();
        System.out.println("Ingresa la fecha, en formato dd/MM/yyyy");
        String date = scan.nextLine();
        if (controller.addPhotoGalaxy(galaxia, url, telescope-1, date)) {
            System.out.println("Se agrego correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }



    public void addPhotoBlackHole(){
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println("Ingresa la url de la foto");
        String url = scan.nextLine();
        System.out.println("Ingresa el telescopio");
        System.out.println(controller.showTelescopes());
        int telescope = scan.nextInt();
        scan.nextLine();
        System.out.println("Ingresa la fecha, en formato dd/MM/yyyy");
        String date = scan.nextLine();
        if (controller.addPhotoBlackHole(galaxia, url, telescope-1, date)) {
            System.out.println("Se agrego correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }

    public void addPhotoPlanet(){
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println("Ingresa el nombre del planeta");
        String name = scan.nextLine();
        System.out.println("Ingresa la url de la foto");
        String url = scan.nextLine();
        System.out.println("Ingresa el telescopio");
        System.out.println(controller.showTelescopes());
        int telescope = scan.nextInt();
        scan.nextLine();
        System.out.println("Ingresa la fecha, en formato dd/MM/yyyy");
        String date = scan.nextLine();
        if (controller.addPhotoPlanet(galaxia, name, url, telescope-1, date)) {
            System.out.println("Se agrego correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }

    public void showGalaxyInfo(){
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println(controller.showGalaxyInfo(galaxia));
    }

    public void showPlanetInfo(){
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Escribe el nombre de la galaxia a la cual pertenece el planeta");
        String galaxia = scan.nextLine();
        System.out.println("Ingresa el nombre del planeta");
        String name = scan.nextLine();
        System.out.println(controller.showPlanetInfo(galaxia, name));
    }


}
