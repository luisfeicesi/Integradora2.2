package model;

public enum Telescope {
    ALMA, IRAM, LMT, SMA, SMT, SPT, JCMT, NPG
    
}
