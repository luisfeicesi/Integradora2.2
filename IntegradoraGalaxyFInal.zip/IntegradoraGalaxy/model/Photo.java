package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The `Photo` class represents a photograph taken by a telescope, storing information about its URL,
 * the telescope used, and the date it was taken.
 */
public class Photo {
    private String url;
    private Telescope telescope;
    private Date date;

    /**
     * Constructs a new `Photo` with the specified parameters.
     *
     * @param url         The URL of the photo.
     * @param telescope   The telescope used to capture the photo.
     * @param dateString  A string representing the date the photo was taken (in the "dd/MM/yyyy" format).
     * @throws ParseException If there is an error parsing the date string.
     */
    public Photo(String url, Telescope telescope, String dateString) throws ParseException {
        this.url = url;
        this.telescope = telescope;

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.date = dateFormat.parse(dateString);
    }

    /**
     * Returns the URL of the photo.
     *
     * @return The URL of the photo.
     */
    public String getUrl() {
        return url;
    }

    /**
     * Sets the URL of the photo.
     *
     * @param url The URL to set.
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Returns the telescope used to capture the photo.
     *
     * @return The telescope used to capture the photo.
     */
    public Telescope getTelescope() {
        return telescope;
    }

    /**
     * Sets the telescope used to capture the photo.
     *
     * @param telescope The telescope to set.
     */
    public void setTelescope(Telescope telescope) {
        this.telescope = telescope;
    }

    /**
     * Returns the date the photo was taken.
     *
     * @return The date the photo was taken.
     */
    public Date getDate() {
        return date;
    }

    /**
     * Sets the date the photo was taken.
     *
     * @param date The date to set.
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Generates a string representation of the photo, including its URL, telescope, and date.
     *
     * @return A formatted string describing the photo and its properties.
     */
    @Override
    public String toString() {
        return "Photo\n" +
                "url= " + url +
                "\n telescope= " + telescope + "\n date= " + date.toString();
    }
}

