package model;

public enum ShapeGalaxy {
    ESPIRAL, IRREGULAR, LENTICULAR, ELIPTICA
}
