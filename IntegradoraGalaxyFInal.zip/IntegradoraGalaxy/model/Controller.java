package model;


import java.text.ParseException;
import java.util.Objects;

/**
 * Controller
 */
public class Controller {
    private Galaxy[] galaxies;

    public Controller() {
        galaxies = new Galaxy[50];

    }

    /**
     * Searches for a galaxy by name.
     *
     * @param nameGal The name of the galaxy to search for.
     * @return The galaxy with the specified name or null if not found.
     */
    public Galaxy searchGalaxy(String nameGal) {
        for (int i = 0; i < galaxies.length; i++) {
            if (galaxies[i] != null) {
                if ( Objects.equals(galaxies[i].getName(), nameGal) ) {
                    return galaxies[i];
                }
            }
        }
        return null;
    }

    /**
     * Creates a new galaxy with the specified parameters.
     *
     * @param nameGal The name of the new galaxy.
     * @param distanceGal The distance of the new galaxy.
     * @param shapeGalaxy The shape of the new galaxy (as an index).
     * @return True if the galaxy is created successfully, false if it already exists or the array is full.
     */
    public boolean createGalaxy(String nameGal, double distanceGal, int shapeGalaxy) {
        if (searchGalaxy(nameGal) != null) {
            return false;
        }
        for (int i = 0; i < galaxies.length; i++) {
            if (galaxies[i] == null) {
                galaxies[i] = new Galaxy(nameGal, distanceGal, ShapeGalaxy.values()[shapeGalaxy]);
                return true;
            }
        }
        return false;
    }

    /**
     * Creates a new black hole in a galaxy with the specified parameters.
     *
     * @param nameGalaxy The name of the galaxy to add the black hole to.
     * @param nameBlack The name of the new black hole.
     * @param distanceBlack The distance of the black hole.
     * @param masa The mass of the black hole.
     * @param blackHoleShape The shape of the black hole (as an index).
     * @return True if the black hole is created successfully, false if the galaxy is not found or the black hole already exists.
     */

    public boolean createBlackhole(String nameGalaxy, String nameBlack, double distanceBlack, double masa, int blackHoleShape) {
        Galaxy galaxy = searchGalaxy(nameGalaxy);
        if (galaxy == null) {
            return false;
        }
        return galaxy.addBlackHole(new BlackHole(nameBlack, masa, distanceBlack, BlackHoleType.values()[blackHoleShape]));
    }

    /**
     * Creates a new planet in a galaxy with the specified parameters.
     *
     * @param nameGalaxy The name of the galaxy to add the planet to.
     * @param name The name of the new planet.
     * @param numberSatellite The number of satellites of the planet.
     * @param radio The radius of the planet.
     * @param masa The mass of the planet.
     * @return True if the planet is created successfully, false if the galaxy is not found or the planet already exists.
     */
    public boolean createPlanet(String nameGalaxy, String name, int numberSatellite, double radio, double masa) {
        Galaxy galaxy = searchGalaxy(nameGalaxy);
        if (galaxy == null) {
            return false;
        }
        return galaxy.addPlanet(new Planet(name, numberSatellite, radio, masa));
    }

    /**
     * Deletes a planet from a galaxy.
     *
     * @param nameGalaxy The name of the galaxy to remove the planet from.
     * @param namePlanet The name of the planet to delete.
     * @return True if the planet is deleted successfully, false if the galaxy or planet is not found.
     */
    public boolean deletePlanet(String nameGalaxy, String namePlanet) {
        Galaxy galaxy = searchGalaxy(nameGalaxy);
        if (galaxy == null) {
            return false;
        }
        return galaxy.deletePlanet(namePlanet);
    }

    /**
     * Customizes the properties of a planet in a galaxy.
     *
     * @param nameGalaxy The name of the galaxy containing the planet.
     * @param oldNamePlanet The name of the planet to customize.
     * @param newNamePlanet The new name for the planet.
     * @param numberSatellite The new number of satellites.
     * @param radio The new radius of the planet.
     * @param masa The new mass of the planet.
     * @return True if the planet is customized successfully, false if the galaxy or planet is not found.
     */
    public boolean customPlanet(String nameGalaxy, String oldNamePlanet, String newNamePlanet, int numberSatellite, double radio, double masa){
        Galaxy galaxy = searchGalaxy(nameGalaxy);
        if (galaxy == null) {
            return false;
        }
        return galaxy.customPlanet(oldNamePlanet, newNamePlanet, numberSatellite, radio, masa);
    }

    /**
     * Adds a photo to a galaxy.
     *
     * @param nameGalaxy The name of the galaxy to add the photo to.
     * @param url The URL of the photo.
     * @param telescope The telescope used for the photo (as an index).
     * @param date The date of the photo.
     * @return True if the photo is added successfully, false if the galaxy is not found or there is an issue with the date.
     */
    public boolean addPhotoGalaxy(String nameGalaxy, String url, int telescope, String date){
        try {
            Galaxy pio = searchGalaxy(nameGalaxy);
            if(pio == null){
                return false;
            }
            return pio.addPhoto(new Photo(url, Telescope.values()[telescope], date));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Adds a photo to a planet in a specific galaxy.
     *
     * @param nameGalaxy The name of the galaxy to which the photo will be added.
     * @param namePlanet The name of the planet to which the photo will be added.
     * @param url The URL of the photo.
     * @param telescope The telescope used for the photo (as an index).
     * @param date The date of the photo.
     * @return True if the photo is successfully added, false if the galaxy is not found or there is an issue with the date.
     */
    public boolean addPhotoPlanet(String nameGalaxy,String namePlanet, String url, int telescope, String date){
        try{
        Galaxy pio = searchGalaxy(nameGalaxy);
        if(pio == null){
            return false;
        }
        return pio.addPhotoToPlanet(namePlanet, new Photo(url, Telescope.values()[telescope], date));
        } catch(Exception e){
            return false;
        }
    }

    /**
     * Adds a photo to a black hole in a specific galaxy.
     *
     * @param nameGalaxy The name of the galaxy to which the photo will be added.
     * @param url The URL of the photo.
     * @param telescope The telescope used for the photo (as an index).
     * @param date The date of the photo.
     * @return True if the photo is successfully added, false if the galaxy is not found or there is an issue with the date.
     */
    public boolean addPhotoBlackHole(String nameGalaxy, String url, int telescope, String date){
        try {
            Galaxy pio = searchGalaxy(nameGalaxy);
            if(pio == null){
                return false;
            }
            return pio.addPhotoBlackHole(new Photo(url, Telescope.values()[telescope], date));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Displays information about a specific galaxy.
     *
     * @param name The name of the galaxy for which information will be displayed.
     * @return A string containing information about the galaxy or a message if the galaxy is not found.
     */
    public String showGalaxyInfo(String name){
        Galaxy pio = searchGalaxy(name);
        if(pio == null){
            return "No se encontro la galaxia";
        }
        return pio.toString();
    }

    /**
     * Displays information about a planet in a specific galaxy.
     *
     * @param nameGalaxy The name of the galaxy to which the planet belongs.
     * @param namePlanet The name of the planet for which information will be displayed.
     * @return A string containing information about the planet or a message if the galaxy or planet is not found.
     */
    public String showPlanetInfo(String nameGalaxy, String namePlanet){
        Galaxy pio = searchGalaxy(nameGalaxy);
        if(pio == null){
            return "No se encontro la galaxia";
        }
        Planet planet = pio.searchPlanet(namePlanet);
        if(planet == null){
            return "No se encontro el planeta";
        }
        return pio.searchPlanet(namePlanet).toString();
    }

    /**
     * Displays the names of all available galaxies.
     *
     * @return A string containing the names of all available galaxies, numbered.
     */
    public String ShowEachGalaxy() {
        String miau = "";
        for (int i = 0; i < galaxies.length; i++) {
            if (galaxies[i] != null) {
                miau += (i + 1) + ". " + galaxies[i].getName() + "\n";
            }
        }
        return miau;
    }

    /**
     * Displays the names of available black hole types.
     *
     * @return A string containing the names of black hole types.
     */
    public String showShapesBlackhole() {
        String guau = "";
        BlackHoleType[] shapeBlackHoleShapes = BlackHoleType.values();
        for (int i = 0; i < shapeBlackHoleShapes.length; i++) {
            guau += (i + 1) + ". " + shapeBlackHoleShapes[i] + "\n";
        }
        return guau;
    }

    /**
     * Displays the names of available galaxy shapes.
     *
     * @return A string containing the names of galaxy shapes.
     */
    public String showShapesGalaxy() {
        String msg = "";
        ShapeGalaxy[] shapeGalaxies = ShapeGalaxy.values();
        for (int i = 0; i < shapeGalaxies.length; i++) {
            msg += (i + 1) + ". " + shapeGalaxies[i] + "\n";
        }
        return msg;
    }

    /**
     * Displays the names of available telescopes.
     *
     * @return A string containing the names of telescopes.
     */
    public String showTelescopes() {
        String msg = "";
        Telescope[] telescopes = Telescope.values();
        for (int i = 0; i < telescopes.length; i++) {
            msg += (i + 1) + ". " + telescopes[i] + "\n";
        }
        return msg;
    }

    /**
     * Retrieves information about the farthest galaxy.
     *
     * @return A string containing information about the farthest galaxy.
     */
    public String consultFarthestGalaxy(){
        String msg = "";
        double distance = 0;
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i] != null){
                if(galaxies[i].getDistance() > distance){
                    distance = galaxies[i].getDistance();
                    msg = galaxies[i].toString();
                }
            }
        }
        return msg;
    }

    /**
     * Retrieves information about the planet with the highest density among the available galaxies.
     *
     * @return A string containing information about the planet with the highest density.
     */
    public String consultPlanetWithMoreDensity(){
        String msg = "";
        double density = 0;
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i] != null){
                for (int j = 0; j < galaxies[i].getPlanets().length; j++) {
                    if(galaxies[i].getPlanets()[j] != null){
                        if(galaxies[i].getPlanets()[j].calculateDensity() > density){
                            density = galaxies[i].getPlanets()[j].calculateDensity();
                            msg = galaxies[i].getPlanets()[j].toString();
                        }
                    }
                }
            }
        }
        return msg;
    }

    /**
     * Retrieves information about the black hole with the highest density among the available galaxies.
     *
     * @return A string containing information about the black hole with the highest density.
     */
    public String consultBlackHoleByType(){
        String msg = "";
        String[] type = {"", "", "", ""};
        BlackHoleType[] blackHoleTypes = BlackHoleType.values();
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i] != null){
                switch (galaxies[i].getBlackhole().getType()){
                    case SCHWARZSCHILD:
                        type[0] +=  " Galaxia: " + galaxies[i].getName() + "\n";
                        break;
                    case KERR:
                        type[1] +=  " Galaxia: " + galaxies[i].getName() + "\n";
                        break;
                    case REISSNER_NORDSTROM:
                        type[2] +=  " Galaxia: " + galaxies[i].getName() + "\n";
                        break;
                    case KERR_NEWMAN:
                        type[3] +=  " Galaxia: " + galaxies[i].getName() + "\n";
                        break;
                }
            }
        }

        for (int i = 0; i < type.length; i++) {
            if(type[i] == ""){
                type[i] = "No hay agujeros negros con este tipo.";
            }
            msg += blackHoleTypes[i] + ": \n" + type[i];
        }
        return msg;
    }

    /**
     * Retrieves information about the telescope with the most photos taken across galaxies.
     *
     * @return A string indicating the telescope with the most photos taken, or a message if no photos were found.
     */

    public String consultTelescopeWithMorePhotos() {
        int[] count = new int[Telescope.values().length];


        // Itera a través de las galaxias para contar las fotos de cada telescopio
        for (int galaxyIndex = 0; galaxyIndex < galaxies.length; galaxyIndex++) {
            Galaxy galaxy = galaxies[galaxyIndex];

            if(galaxy != null){

                // planets
                for (int planetIndex = 0; planetIndex < galaxy.getPlanets().length; planetIndex++){
                    Planet planet = galaxy.getPlanets()[planetIndex];

                    if ( planet != null ){
                        for (int photoIndex = 0; photoIndex < planet.getPhotos().length; photoIndex++){
                            Photo photo = planet.getPhotos()[photoIndex];

                            if ( photo != null ){
                                int telescopeIndex = photo.getTelescope().ordinal();
                                count[telescopeIndex]++;
                            }
                        }
                    }
                }

                // Fotos de agujeros negros
                BlackHole blackHole = galaxy.getBlackhole();
                if ( blackHole != null ){
                    for (int photoIndex = 0; photoIndex < blackHole.getPhotos().length; photoIndex++){
                        Photo photo = blackHole.getPhotos()[photoIndex];

                        if ( photo != null ){
                            int telescopeIndex = photo.getTelescope().ordinal(); // Ordinal me da la posicion de donde se ubica esa enumeracion con el metodo values()
                            count[telescopeIndex]++;
                        }
                    }
                }

                // Fotos de la galaxia
                for (int photoIndex = 0; photoIndex < galaxy.getPhotos().length; photoIndex++){
                    Photo photo = galaxy.getPhotos()[photoIndex];

                    if ( photo != null ){
                        int telescopeIndex = photo.getTelescope().ordinal();
                        count[telescopeIndex]++;
                    }
                }
            }
        }

        // Encuentra el índice del telescopio con más fotos
        int maxCount = 0;
        int maxCountTelescopeIndex = -1;

        for (int i = 0; i < count.length; i++) {
            if (count[i] > maxCount) {
                maxCount = count[i];
                maxCountTelescopeIndex = i;
            }
        }

        if (maxCountTelescopeIndex != -1) {
            Telescope telescopeWithMostPhotos = Telescope.values()[maxCountTelescopeIndex];
            return "El telescopio con más fotos es: " + telescopeWithMostPhotos;
        } else {
            return "No se encontraron fotos con telescopios.";
        }
    }

    public void testCase() {
        createGalaxy("Via Lactea", Math.random() * 100000, (int) (Math.random() * 4));
        createGalaxy("Andromeda", Math.random() * 100000, (int) (Math.random() * 4));
        createGalaxy("Centaurus A", Math.random() * 100000, (int) (Math.random() * 4));
        createGalaxy("Messier 87", Math.random() * 100000, (int) (Math.random() * 4));
        createBlackhole("Via Lactea", "Sagitario A", Math.random() * 100000, Math.random() * 100000, (int) (Math.random() * 4));
        createBlackhole("Andromeda", "Sagitario A", Math.random() * 100000, Math.random() * 100000, (int) (Math.random() * 4));
        createBlackhole("Centaurus A", "Sagitario A", Math.random() * 100000, Math.random() * 100000, (int) (Math.random() * 4));
        createBlackhole("Messier 87", "Sagitario A", Math.random() * 100000, Math.random() * 100000, (int) (Math.random() * 4));
        createPlanet("Via Lactea", "Tierra", (int) (Math.random() * 10), Math.random() * 100, Math.random() * 100);
        createPlanet("Andromeda", "Tierra", (int) (Math.random() * 10), Math.random() * 100, Math.random() * 100);
        createPlanet("Centaurus A", "Tierra", (int) (Math.random() * 10), Math.random() * 100, Math.random() * 100);
        createPlanet("Messier 87", "Tierra", (int) (Math.random() * 10), Math.random() * 100, Math.random() * 100);
        addPhotoPlanet("Via Lactea", "Tierra", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoGalaxy("Via Lactea", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoBlackHole("Via Lactea", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoPlanet("Andromeda", "Tierra", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoGalaxy("Andromeda", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoBlackHole("Andromeda", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoPlanet("Centaurus A", "Tierra", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoGalaxy("Centaurus A", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoBlackHole("Centaurus A", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoPlanet("Messier 87", "Tierra", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoGalaxy("Messier 87", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
        addPhotoBlackHole("Messier 87", "https://www.nasa.gov/sites/default/files/thumbnails/image/potw2021a.jpg", (int) (Math.random() * 4), "12/12/2021");
    }

}