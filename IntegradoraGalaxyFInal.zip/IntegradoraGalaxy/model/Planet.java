package model;


public class Planet {
    private String name;
    private int numberSatellite;
    private double radio;
    private double masa;
    private double density;
    private double volumen;
    private Photo[] photos;

    /**
     * Constructs a new `Planet` with the specified parameters.
     *
     * @param name            The name of the planet.
     * @param numberSatellite The number of satellites or moons.
     * @param radio           The radius of the planet.
     * @param masa            The mass of the planet.
     */
    public Planet(String name, int numberSatellite, double radio, double masa) {
        this.name = name;
        this.numberSatellite = numberSatellite;
        this.radio = radio;
        this.masa = masa;
        this.volumen = calculateVolumen();
        this.density = calculateDensity();
        this.photos = new Photo[50];
    }

    /**
     * Returns the density of the planet.
     *
     * @return The density of the planet.
     */
    public double getDensity() {
        return density;
    }

    /**
     * Sets the density of the planet.
     *
     * @param density The density to set.
     */
    public void setDensity(double density) {
        this.density = density;
    }

    /**
     * Returns the volume of the planet.
     *
     * @return The volume of the planet.
     */
    public double getVolumen() {
        return volumen;
    }

    /**
     * Sets the volume of the planet.
     *
     * @param volumen The volume to set.
     */
    public void setVolumen(double volumen) {
        this.volumen = volumen;
    }

    /**
     * Calculates and returns the volume of the planet using its radius.
     *
     * @return The calculated volume of the planet.
     */
    public double calculateVolumen() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);
    }

    /**
     * Calculates and returns the density of the planet using its mass and volume.
     *
     * @return The calculated density of the planet.
     */
    public double calculateDensity() {
        return masa / volumen;
    }

    /**
     * Returns the name of the planet.
     *
     * @return The name of the planet.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the planet.
     *
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the number of satellites or moons orbiting the planet.
     *
     * @return The number of satellites or moons.
     */
    public int getNumberSatellite() {
        return numberSatellite;
    }

    /**
     * Sets the number of satellites or moons orbiting the planet.
     *
     * @param numberSatellite The number of satellites to set.
     */
    public void setNumberSatellite(int numberSatellite) {
        this.numberSatellite = numberSatellite;
    }

    /**
     * Returns the radius of the planet.
     *
     * @return The radius of the planet.
     */
    public double getRadio() {
        return radio;
    }

    /**
     * Sets the radius of the planet.
     *
     * @param radio The radius to set.
     */
    public void setRadio(double radio) {
        this.radio = radio;
    }

    /**
     * Returns the mass of the planet.
     *
     * @return The mass of the planet.
     */
    public double getMasa() {
        return masa;
    }

    /**
     * Sets the mass of the planet.
     *
     * @param masa The mass to set.
     */
    public void setMasa(double masa) {
        this.masa = masa;
    }

    /**
     * Returns an array of photos associated with the planet.
     *
     * @return An array of photos.
     */
    public Photo[] getPhotos() {
        return photos;
    }

    /**
     * Sets the array of photos associated with the planet.
     *
     * @param photos The array of photos to set.
     */
    public void setPhotos(Photo[] photos) {
        this.photos = photos;
    }

    /**
     * Adds a photo to the planet's array of photos.
     *
     * @param photo The photo to add.
     * @return `true` if the photo was added successfully, `false` if the array is full.
     */
    public boolean addPhoto(Photo photo) {
        for (int i = 0; i < photos.length; i++) {
            if (photos[i] == null) {
                photos[i] = photo;
                return true;
            }
        }
        return false;
    }

    /**
     * Generates a string containing information about the photos associated with the planet.
     *
     * @return A string with URLs of the photos.
     */
    public String showPhotos() {
        String msg = "";
        for (int i = 0; i < photos.length; i++) {
            if (photos[i] != null) {
                msg += photos[i].getUrl();
            }
        }
        return msg;
    }

    /**
     * Returns a string representation of the planet, including its attributes and associated photos.
     *
     * @return A formatted string describing the planet and its properties.
     */
    @Override
    public String toString() {
        return "Planet\n" +
                "\nname= " + name +
                "\n number Satellite= " + numberSatellite +
                "\n radio= " + radio +
                "\n masa= " + masa +
                "\n density= " + density +
                "\n volumen= " + volumen +
                "\n photos= " + showPhotos();
    }
}

