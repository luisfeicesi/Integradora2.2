package model;


public class Galaxy {
    private String name;
    private double distance;
    private ShapeGalaxy shapeGalaxy;
    private Photo[] photos;
    private Planet[] planets;
    private BlackHole blackhole; 

    public Galaxy(String name, double distance, ShapeGalaxy shapeGalaxy) {
        this.name = name;
        this.distance = distance;
        this.shapeGalaxy = shapeGalaxy;
        this.planets = new Planet[20];
        this.photos = new Photo[30]; 
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public double getDistance() {
        return distance;
    }


    public void setDistance(double distance) {
        this.distance = distance;
    }


    public ShapeGalaxy getShapeGalaxy() {
        return shapeGalaxy;
    }


    public void setShapeGalaxy(ShapeGalaxy shapeGalaxy) {
        this.shapeGalaxy = shapeGalaxy;
    }


    public Planet[] getPlanets() {
        return planets;
    }


    public void setPlanets(Planet[] planets) {
        this.planets = planets;
    }


    public BlackHole getBlackhole() {
        return blackhole;
    }

    public void setBlackhole(BlackHole blackhole) {
        this.blackhole = blackhole;
    }


    public boolean addPlanet(Planet planet) {
        if(searchPlanet(planet.getName()) != null){
            return false;
        }
        for (int i = 0; i < planets.length; i++) {
            if(planets[i] == null){
                planets[i] = planet;
                return true;
            }
        }
        return false;
    }

    public boolean addBlackHole(BlackHole blackHole){
        if(this.blackhole == null){
            this.blackhole = blackHole;
            return true;
        }
        return false; 
    }

    public Planet searchPlanet(String name){
        for (int i = 0; i < planets.length; i++) {
            if(this.planets[i] != null){
                if(this.planets[i].getName().equals(name)){
                    return this.planets[i];
                }
            }
        }
        return null;
    }

    public boolean deletePlanet(String namePlanet){
        for (int i = 0; i < planets.length; i++) {
            if(this.planets[i] != null){
                if(this.planets[i].getName().equals(name)){
                    this.planets[i] = null;
                    return true;
                }
            }
        }
        return false;

    }

    public boolean customPlanet(String oldNamePlanet, String newNamePlanet, int numberSatellite, double radio, double masa){
        Planet planetmiau = searchPlanet(oldNamePlanet);  
        if(oldNamePlanet == null){
            return false;
        }
        if(searchPlanet(newNamePlanet) != null){
            return false;
        }
        planetmiau.setName(newNamePlanet);
        planetmiau.setNumberSatellite(numberSatellite);
        planetmiau.setRadio(radio);
        planetmiau.setMasa(masa);
        planetmiau.setVolumen(planetmiau.calculateVolumen());
        planetmiau.setDensity(planetmiau.calculateDensity());
        return true;
    }

    public boolean addPhotoBlackHole(Photo photo){
        if(this.blackhole == null){
            return false;
        }
        return this.blackhole.addPhoto(photo);
    }

    public boolean addPhotoToPlanet(String name, Photo photo){
        Planet guau = searchPlanet(name);
        if(guau == null){
            return false;
        }
        return guau.addPhoto(photo);
    }


    public boolean addPhoto(Photo photo){
        for (int i = 0; i < photos.length; i++) {
            if(photos[i] == null){
                photos[i] = photo;
                return true;
            }
        }
        return false;
    }


    public String showPhotos(){
        String msg = "";
        for (int i = 0; i < photos.length; i++) {
            if(photos[i] != null){
                msg += photos[i].getUrl();
            }
        }
        return msg;
    }

    public String showPlanets(){
        String msg = "";
        for (int i = 0; i < planets.length; i++) {
            if(planets[i] != null){
                msg += planets[i].getName();
            }
        }
        return msg;
    }

    public Photo[] getPhotos() {
        return photos;
    }

    public void setPhotos(Photo[] photos) {
        this.photos = photos;
    }

    @Override
    public String toString() {
        return "Galaxy" +
                "\n name= " + name + "\n distance= " + distance + "\n shapeGalaxy= " + shapeGalaxy + "\n photos= "
                + showPhotos() + "\n planets= " + showPlanets() + "\n blackhole= " + blackhole.getName();
    }

    
}
