package model;

public enum BlackHoleType{
    SCHWARZSCHILD, REISSNER_NORDSTROM, KERR, KERR_NEWMAN
}
