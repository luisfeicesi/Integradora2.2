package model;

/**
 * The `BlackHole` class represents a black hole in space, storing information about its name, mass,
 * distance to Earth, associated photos, and type.
 */
public class BlackHole {
    private String name;
    private double masa;
    private double distance;
    private Photo[] photos;
    private BlackHoleType type;

    /**
     * Constructs a new `BlackHole` with the specified parameters.
     *
     * @param name            The name of the black hole.
     * @param masa            The mass of the black hole.
     * @param distancealaTierra The distance from the black hole to Earth.
     * @param type            The type of the black hole (e.g., Schwarzschild, Kerr, etc.).
     */
    public BlackHole(String name, double masa, double distancealaTierra, BlackHoleType type) {
        this.name = name;
        this.masa = masa;
        this.distance = distancealaTierra;
        this.photos = new Photo[5];
        this.type = type;
    }

    /**
     * Returns an array of photos associated with the black hole.
     *
     * @return An array of photos.
     */
    public Photo[] getPhotos() {
        return photos;
    }

    /**
     * Sets the array of photos associated with the black hole.
     *
     * @param photos The array of photos to set.
     */
    public void setPhotos(Photo[] photos) {
        this.photos = photos;
    }

    /**
     * Returns the type of the black hole.
     *
     * @return The type of the black hole.
     */
    public BlackHoleType getType() {
        return type;
    }

    /**
     * Sets the type of the black hole.
     *
     * @param type The type to set.
     */
    public void setType(BlackHoleType type) {
        this.type = type;
    }

    /**
     * Returns the name of the black hole.
     *
     * @return The name of the black hole.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the black hole.
     *
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the mass of the black hole.
     *
     * @return The mass of the black hole.
     */
    public double getMasa() {
        return masa;
    }

    /**
     * Sets the mass of the black hole.
     *
     * @param masa The mass to set.
     */
    public void setMasa(double masa) {
        this.masa = masa;
    }

    /**
     * Returns the distance from the black hole to Earth.
     *
     * @return The distance from the black hole to Earth.
     */
    public double getDistance() {
        return distance;
    }

    /**
     * Sets the distance from the black hole to Earth.
     *
     * @param distancealaTierra The distance to set.
     */
    public void setDistance(double distancealaTierra) {
        this.distance = distancealaTierra;
    }

    /**
     * Adds a photo to the black hole's array of photos.
     *
     * @param photo The photo to add.
     * @return `true` if the photo was added successfully, `false` if the array is full.
     */
    public boolean addPhoto(Photo photo) {
        boolean added = false;
        for (int i = 0; i < photos.length && !added; i++) {
            if (photos[i] == null) {
                try {
                    photos[i] = photo;
                    added = true;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return added;
    }

    /**
     * Generates a string containing information about the photos associated with the black hole.
     *
     * @return A string with URLs of the photos.
     */
    public String showPhotos() {
        String message = "";
        for (int i = 0; i < photos.length; i++) {
            if (photos[i] != null) {
                message += photos[i].getUrl() + "\n";
            }
        }
        return message;
    }

    /**
     * Returns a string representation of the black hole, including its attributes and associated photos.
     *
     * @return A formatted string describing the black hole and its properties.
     */
    @Override
    public String toString() {
        return "BlackHole" +
                "\n distance= " + distance + "\n masa= " + masa + "\n name= " + name + "\nphotos= "
                + showPhotos() + "\n type= " + type;
    }
}
