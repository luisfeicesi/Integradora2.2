package model;

public class Galaxy {
    private String name;
    private double distance;
    private ShapeGalaxy shapeGalaxy;
    private Planet[] planets;
    private BlackHole blackhole; 

    public Galaxy(String name, double distance, ShapeGalaxy shapeGalaxy) {
        this.name = name;
        this.distance = distance;
        this.shapeGalaxy = shapeGalaxy;
        this.planets = new Planet[20];
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public double getDistance() {
        return distance;
    }


    public void setDistance(double distance) {
        this.distance = distance;
    }


    public ShapeGalaxy getShapeGalaxy() {
        return shapeGalaxy;
    }


    public void setShapeGalaxy(ShapeGalaxy shapeGalaxy) {
        this.shapeGalaxy = shapeGalaxy;
    }


    public Planet[] getPlanets() {
        return planets;
    }


    public void setPlanets(Planet[] planets) {
        this.planets = planets;
    }


    public BlackHole getBlackhole() {
        return blackhole;
    }

    public void setBlackhole(BlackHole blackhole) {
        this.blackhole = blackhole;
    }


    public boolean addPlanet(Planet planet) {
        return false;
    }
}
