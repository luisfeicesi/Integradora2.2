package model;

public enum BlackHoleShape {
    SCHWARZSCHILD, REISSNER_NORDSTROM, KERR, KERR_NEWMAN
}
