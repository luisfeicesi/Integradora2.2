package model;

/**
 * Controller
 */
public class Controller {
    private Galaxy[] galaxies;
    private BlackHole[] blackholes;


    public Controller(){
        galaxies = new Galaxy[50];
        blackholes = new BlackHole[4];
        
    }

    public boolean createGalaxy(String nameGal, double distanceGal, int shapeGalaxy){ 
        if(searchGalaxy(nameGal) != null){
            return false;
        }
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i] == null ){
                galaxies[i] = new Galaxy(nameGal, distanceGal, ShapeGalaxy.values()[shapeGalaxy]);
                return true;
            }
        }
        return false;
    }

    public boolean createBlackhole(String nameBlack, double distanceBlack, int BlackHoleShape){ 
        if(searchGalaxy(nameBlack) != null){
            return false;
        }
        for (int i = 0; i < blackholes.length; i++) {
            if(blackholes[i] == null ){
                blackholes[i] = new BlackHole(nameBlack, distanceBlack, ShapeGalaxy.values()[BlackHoleShape]);
                return true;
            }
        }
        return false;
    }

    public boolean createPlanet(int posGalaxia, String name, int numberSatellite, double radio, double masa){
        Galaxy galaxy = galaxies[posGalaxia-1];
        return galaxy.addPlanet(new Planet(name, numberSatellite, radio, masa));
    }

    public Galaxy searchGalaxy(String nameGal){
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i] != null){
                if(galaxies[i].getName() == nameGal){
                    return galaxies[i];
                }
            }
        }
        return null;
    } 

    public String ShowEachGalaxy(){
        String miau = "";
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i]!=null){
                miau += i+1 + ". " + galaxies[i].toString() + "\n";
            }
        }
        return miau;
    }

    public String showPlanetsOfGalaxy(){
        String miau = "";
        for (int i = 0; i < galaxies.length; i++) {
            if(galaxies[i] != null){
                for (int j = 0; j < galaxies[i].getPlanets().length; j++) {
                    if(galaxies[i].getPlanets()[j] != null){
                        miau += "Name: " + galaxies[i].getPlanets()[j].toString() + "\n";
                    }
                }
            }
        }
        return miau;
    }


    public String showShapesBlackhole(){
        String guau = "";
        BlackHoleShape[] shapeBlackHoleShapes = BlackHoleShape.values();
        for (int i = 0; i < shapeBlackHoleShapes.length; i++) {
            guau += i+1 + ". " + shapeBlackHoleShapes[i] + "\n";
        }
        return guau;
    }

    public String showShapesGalaxy(){
        String msg = "";
        ShapeGalaxy[] shapeGalaxies = ShapeGalaxy.values();
        for (int i = 0; i < shapeGalaxies.length; i++) {
            msg += i+1 + ". " + shapeGalaxies[i] + "\n";
        }
        return msg;
    }

    public boolean createGalaxyBlackhole(String nameGal, double distanceGal, int shapeGal, String nameBlack,
            double distanceBlack, BlackHoleShape blackHoleShape) {
        return false;
    }

}