package model;

public class BlackHole {
    private String name;
    private double masa;
    private double distancealaTierra;

    public BlackHole(String name, double masa, double distancealaTierra) {
        this.name = name;
        this.masa = masa;
        this.distancealaTierra = distancealaTierra;
    }

    public BlackHole(String nameBlack, double distanceBlack, ShapeGalaxy shapeGalaxy) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    public double getDistancealaTierra() {
        return distancealaTierra;
    }

    public void setDistancealaTierra(double distancealaTierra) {
        this.distancealaTierra = distancealaTierra;
    }

}