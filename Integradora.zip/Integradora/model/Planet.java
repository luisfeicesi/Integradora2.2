package model;

public class Planet {
    private String name;
    private int numberSatellite;
    private double radio;
    private double masa;
    private double density;
    private double volumen;
    private int numPhotos;



    public Planet(String name, int numberSatellite, double radio, double masa) {
        this.name = name;
        this.numberSatellite = numberSatellite;
        this.radio = radio;
        this.masa = masa;
        this.volumen = calculateVolumen();
        this.density = calculateDesinty();
        this.numPhotos = 0;
    }

    public double getDensity() {
        return density;
    }

    public void setDensity(double density) {
        this.density = density;
    }

    public double getVolumen() {
        return volumen;
    }

    public void setVolumen(double volumen) {
        this.volumen = volumen;
    }

    private double calculateVolumen() {
        return (4 / 3) * Math.PI * Math.pow(radio, 3);
    }

    private double calculateDesinty() {
        return masa / volumen;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberSatellite() {
        return numberSatellite;
    }

    public void setNumberSatellite(int numberSatellite) {
        this.numberSatellite = numberSatellite;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    @Override
    public String toString(){
        return "Name: " + this.name;
    }

}
