package ui;
import java.util.Scanner;
import model.BlackHoleShape;
import model.Controller;

//Disculpeme yo ya no di para mas profe

public class Main {
    public Controller controller;
    public Scanner scan;

    public Main() {
        controller = new Controller();
        scan = new Scanner(System.in);
    }

    public static void main(String[] args) {
        Main main = new Main();
        main.menu();
    }

    public void menu() {
        while (true) {
            System.out.println(" ..Bienvenido a los confines del universo.. ");
            System.out.println("--Ingrese una opcion--");
            System.out.println("1. Crear Galaxias y su agujero negro");
            System.out.println("2. Crear un planeta");
            System.out.println("3. Agregar una foto a un planeta");
            System.out.println("4. Eliminar planeta");


            int option = scan.nextInt();
            scan.nextLine();
            switch (option) {
                case 1:
                    createGalaxyBlackhole();
                    break;
                case 2:
                    createPlanet();
                    break;
                case 3:

                    break;
            }
        }
    }

    public void createGalaxyBlackhole() {
        System.out.println("Hola inutil, ingresa el nombre de la Galaxia");
        String nameGal = scan.nextLine();
        System.out.println("jaja, dale ahora ingresa la distancia de la galaxia con respecto a la tierra");
        double distanceGal = scan.nextDouble();
        scan.nextLine();
        System.out.println("Ingresa el id de la forma");
        System.out.println(controller.showShapesGalaxy());
        int shapeGal = scan.nextInt();
        scan.nextLine();
        System.out.println("Ingresa el nombre del agujero negro");
        String nameBlack = scan.nextLine();
        System.out.println("jaja, ahora ingresa la distancia del agujero negro con respecto a la tierra");
        double distanceBlack = scan.nextDouble();
        scan.nextLine();
        System.out.println("Ingresa el id del tipo según su carga y momento angular");
        System.out.println(controller.showShapesBlackhole());
        int TypeBlack = scan.nextInt();
        scan.nextLine();
        if (TypeBlack <= 0 || TypeBlack > BlackHoleShape.values().length) {
            System.out.println("ID de tipo inválido, cancelando operación.");
            return;
        }
        if (controller.createGalaxyBlackhole(nameGal, distanceGal, shapeGal, nameBlack, distanceBlack, BlackHoleShape.values()[TypeBlack - 1])) {
            System.out.println("Se creo correctamente");
        } else {
            System.out.println("Ocurrio un problema");
        }
    }

    public void createPlanet() {
        System.out.println(controller.ShowEachGalaxy());
        System.out.println("Listo inutil, selecciona una galaxia");
        int galaxia = scan.nextInt();
        scan.nextLine();
        System.out.println("Ingresa el nombre del planeta");
        String name = scan.nextLine();
        System.out.println("Ingresa el numero de los satelites");
        int numberSatellite = scan.nextInt();
        System.out.println("Ingresa el radio");
        double radio = scan.nextDouble();
        System.out.println("Ingresa la masa");
        double masa = scan.nextDouble();
        if (controller.createPlanet(galaxia, name, numberSatellite, radio, masa)) {
            System.out.println("Se creo correctamente");
            System.out.println(controller.showPlanetsOfGalaxy());
        } else {
            System.out.println("Ocurrio un problema");
        }

    }
}
